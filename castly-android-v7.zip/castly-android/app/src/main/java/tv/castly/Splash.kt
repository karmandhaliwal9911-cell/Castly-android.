package tv.castly

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Start screen: logo + "Castly" on a dark gradient. */
@Composable
fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF16322F), Color(0xFF0B0F14), Color(0xFF1D2B44)))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.castly_logo), null, Modifier.size(140.dp))
            Spacer(Modifier.height(24.dp))
            Text("Castly", color = Color(0xFFEEF1F6), fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
